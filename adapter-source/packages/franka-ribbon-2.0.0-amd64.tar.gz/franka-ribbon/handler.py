"Linux Edge Adapter entrypoint. Self-test never creates a broker or touches hardware."

import argparse
import json
import socket
import subprocess
import sys
import time
from pathlib import Path

# Connector uses python -I: only add this immutable installed package directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import MANIFEST, canonical, envelope, load_config, package_fingerprint, validate


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--invoke")
    p.add_argument("--serve", action="store_true")
    p.add_argument("--config", type=Path, default=Path.home() / ".config/qizhen-franka/config.json")
    a = p.parse_args()
    if a.self_test:
        from jsonschema import Draft202012Validator

        for op in MANIFEST["operations"]:
            Draft202012Validator.check_schema(op["input_schema"])
            Draft202012Validator.check_schema(op["output_schema"])
        print(
            canonical(
                {"ok": True, "operations": len(MANIFEST["operations"]), "hardware_accessed": False}
            )
        )
        return
    config = load_config(a.config)
    if a.serve:
        from broker import serve

        serve(config)
        return
    backend = config["backend"]
    try:
        parameters = json.loads(sys.stdin.read(1024 * 1024 + 1))
        validate(a.invoke, parameters)
        request = {
            "operation_id": a.invoke,
            "parameters": parameters,
            "config_hash": package_fingerprint(config),
        }
        root = Path(config["state_dir"])
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        sock = root / "broker.sock"

        def connect():
            c = socket.socket(socket.AF_UNIX)
            c.settimeout(15)
            try:
                c.connect(str(sock))
            except Exception:
                c.close()
                raise
            return c

        try:
            c = connect()
        except (FileNotFoundError, ConnectionRefusedError):
            with (root / "broker-start.log").open("ab") as log:
                subprocess.Popen(
                    [
                        sys.executable,
                        "-I",
                        str(Path(__file__).resolve()),
                        "--serve",
                        "--config",
                        str(a.config),
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=log,
                    stderr=log,
                    start_new_session=True,
                    close_fds=True,
                )
            c = None
            for _ in range(50):
                try:
                    c = connect()
                    break
                except (FileNotFoundError, ConnectionRefusedError):
                    time.sleep(0.1)
            if c is None:
                raise ValueError(
                    "BROKER_START_FAILED; inspect owner-local broker-start.log"
                ) from None
        with c:
            c.sendall((canonical(request) + "\n").encode())
            with c.makefile("rb") as f:
                b = f.readline(1024 * 1024 + 1)
        result = json.loads(b)
    except Exception as ex:
        result = envelope(
            backend, error={"code": "ADAPTER_REQUEST_FAILED", "message": str(ex)[:2000]}
        )
    print(canonical(result))


if __name__ == "__main__":
    main()
