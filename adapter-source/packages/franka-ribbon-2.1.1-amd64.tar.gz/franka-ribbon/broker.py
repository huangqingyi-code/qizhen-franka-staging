"Owner-local Unix socket broker; persistent PTYs outlive individual tool calls."

import errno
import fcntl
import json
import os
import pty
import re
import select
import signal
import socketserver
import subprocess
import threading
import time
from pathlib import Path
from uuid import uuid4

from stop_guard import session_blocks, verify_stopped

from core import (
    FCI,
    MOTION,
    PACKAGE,
    TERMINAL,
    Store,
    canonical,
    command,
    create_task,
    envelope,
    now,
    package_fingerprint,
    plot_shape,
    shape_extract,
    shell_launch,
    validate,
)


def prompt_actions(operation, text):
    "Recognize only documented prompts; home and delta never wait for input."
    if operation not in {"franka.ribbon.run", "franka.pipeline.start"}:
        return None
    pause = re.search(r"RESUME\s*[/／]\s*(?:(SKIP)\s*[/／]\s*)?QUIT", text)
    if pause:
        return ["RESUME", "SKIP", "QUIT"] if pause.group(1) else ["RESUME", "QUIT"]
    if operation == "franka.pipeline.start" and re.search(
        r"(输入\s*MOVE|(?:enter|type|input)\s+[\"\']?MOVE|最终.*MOVE)", text, re.I
    ):
        return ["MOVE"]
    return None


class Broker:
    def __init__(self, config):
        self.config = config
        self.store = Store(config["state_dir"])
        self.store.backend = config["backend"]
        self.lock = threading.RLock()
        self.live = {}
        self.fingerprint = package_fingerprint(config)
        for s in self.store.data["sessions"].values():
            if s["state"] not in TERMINAL or s["state"] == "unknown":
                legacy_verified = bool(s.get("operator_verified_stopped"))
                s.update(
                    state="failed",
                    error=s.get("error") or "BROKER_RESTART_EXECUTION_OUTCOME_UNVERIFIED",
                    confirmation=None,
                    physical_stop_verified=False,
                    control_lock_pending=not legacy_verified,
                )
            elif s["state"] == "failed" and "control_lock_pending" not in s:
                s["control_lock_pending"] = s["operation_id"] in MOTION
        self.store.save()

    def refresh_failed_lock(self, s):
        if s["state"] != "failed" or not session_blocks(s):
            return
        report = verify_stopped(self.config, s)
        s["stop_verification"] = report
        s["physical_stop_verified"] = report["verified"]
        s["control_lock_pending"] = not report["verified"]
        self.save()

    def refresh_failed_locks(self):
        for s in self.store.data["sessions"].values():
            self.refresh_failed_lock(s)

    def snapshot(self, s):
        return {k: v for k, v in s.items() if k not in {"directory", "argv", "parameters"}}

    def save(self):
        self.store.save()

    def blocked(self):
        return next((s for s in self.store.data["sessions"].values()
                     if s["operation_id"] in FCI and session_blocks(s)), None)

    def prompt(self, s, actions, text):
        s["state"] = "waiting_confirmation"
        s["confirmation"] = {
            "confirmation_id": "confirm_" + uuid4().hex,
            "actions": actions,
            "prompt": text[-16000:],
            "hardware_confirmation_required": self.config["backend"] == "real",
        }
        self.save()

    def finish(self, s, code, data, error=None):
        s["exit_code"] = code
        s["result"] = data
        s["confirmation"] = None
        if s["state"] != "cancelled":
            s["state"] = "succeeded" if error is None else "failed"
        if error is not None:
            s["control_lock_pending"] = (
                s["operation_id"] in MOTION and data.get("started") is not False
            )
            s["physical_stop_verified"] = False
        s["error"] = error
        s["finished_at"] = now()
        self.store.collect(s)
        self.save()

    def invoke(self, op, a):
        with self.lock:
            validate(op, a)
            if op in FCI or op == "franka.ribbon.measure" or op == "franka.session.reconcile":
                self.refresh_failed_locks()
            key = a.get("request_id")
            frozen = canonical({"operation": op, "parameters": a})
            if key in self.store.data["requests"]:
                prior = self.store.data["requests"][key]
                if prior["input"] != frozen:
                    raise ValueError("REQUEST_ID_REUSED_WITH_DIFFERENT_INPUT")
                if prior.get("session_id"):
                    return self.snapshot(self.store.data["sessions"][prior["session_id"]])
                return prior["result"]
            if op == "franka.doctor":
                w = Path(self.config["workspace"])
                paths = [
                    self.config["ros_setup"],
                    str(w / "install/setup.bash"),
                    str(w / "tools/run_pipeline.py"),
                    str(w / "tools/ribbon_level.py"),
                    str(w / "libfranka/build/examples/read_franka_state"),
                    str(w / "libfranka/build/examples/cartesian_delta_move"),
                    str(w / "nokov/build/nokov_recorder"),
                    self.config["python_executable"],
                ]
                result = {
                    "backend": self.config["backend"],
                    "hardware_accessed": False,
                    "checks": [{"path": p, "exists": Path(p).exists()} for p in paths],
                    "ready": self.config["backend"] == "mock"
                    or all(Path(p).is_file() for p in paths),
                    "operations": 24,
                }
            elif op == "franka.task.create":
                result = create_task(self.store, self.config, a)
            elif op == "franka.artifact.read":
                p = self.store.artifact(a["artifact_id"])
                v = self.store.data["artifacts"][a["artifact_id"]]
                with p.open("rb") as f:
                    b = f.read(262145)
                result = {k: x for k, x in v.items() if k != "path"}
                result.update(
                    artifact_id=a["artifact_id"],
                    content=b[:262144].decode("utf-8", errors="replace"),
                    truncated=len(b) > 262144,
                )
            elif op == "franka.shape.extract":
                result = shape_extract(self.store, a["artifact_id"])
            elif op == "franka.shape.plot":
                result = plot_shape(self.store, a["artifact_id"])
            elif op.startswith("franka.session."):
                s = self.store.data["sessions"][a["session_id"]]
                if op == "franka.session.status":
                    self.refresh_failed_lock(s)
                    self.store.collect(s)
                    result = self.snapshot(s)
                elif op == "franka.session.respond":
                    pending = s.get("confirmation")
                    if (
                        s["state"] != "waiting_confirmation"
                        or not pending
                        or pending["confirmation_id"] != a["confirmation_id"]
                        or a["action"] not in pending["actions"]
                    ):
                        raise ValueError("STALE_OR_INVALID_CONFIRMATION")
                    action = a["action"]
                    s["confirmation"] = None
                    s["state"] = "running"
                    s["prompt_epoch"] = s.get("prompt_epoch", 0) + 1
                    if self.config["backend"] == "mock":
                        from mock_backend import respond

                        respond(self, s, action)
                    else:
                        fd, proc = self.live[s["session_id"]]
                        if proc.poll() is not None:
                            raise ValueError("PROCESS_ALREADY_EXITED")
                        os.write(fd, (action + "\n").encode())
                    result = self.snapshot(s)
                elif op == "franka.session.cancel":
                    if s["state"] not in TERMINAL:
                        s.update(
                            state="cancelling", confirmation=None, physical_stop_verified=False
                        )
                        if self.config["backend"] == "mock":
                            s.update(state="cancelled", error=None, finished_at=now())
                        else:
                            live = self.live.get(s["session_id"])
                            proc = live[1] if live else None
                            if proc is not None and proc.poll() is None:
                                os.killpg(proc.pid, signal.SIGINT)
                    result = self.snapshot(s)
                else:
                    if s["state"] != "failed":
                        raise ValueError("RECONCILE_ONLY_FAILED_SESSION")
                    if session_blocks(s):
                        raise ValueError("STOP_NOT_VERIFIED: " + str(s.get("stop_verification", {})))
                    result = self.snapshot(s)
            else:
                if op in FCI and self.blocked():
                    raise ValueError("FCI_BUSY_OR_STOP_UNVERIFIED: " + self.blocked()["session_id"])
                # Shared calibration history needs a separate lock even measure does not use FCI.
                if op in {
                    "franka.ribbon.measure",
                    "franka.ribbon.run",
                    "franka.pipeline.start",
                } and any(
                    s["operation_id"]
                    in {"franka.ribbon.measure", "franka.ribbon.run", "franka.pipeline.start"}
                    and session_blocks(s)
                    for s in self.store.data["sessions"].values()
                ):
                    raise ValueError("RIBBON_SESSION_BUSY")
                sid = "session_" + uuid4().hex
                directory = self.store.root / sid
                directory.mkdir(mode=0o700)
                # Validate all handle mappings before launching even in Mock mode.
                argv, timeout = command(self.config, self.store, op, a, directory)
                s = {
                    "session_id": sid,
                    "operation_id": op,
                    "state": "running",
                    "backend": self.config["backend"],
                    "simulated": self.config["backend"] == "mock",
                    "started_at": now(),
                    "started_unix": time.time(),
                    "directory": str(directory),
                    "argv": argv,
                    "parameters": a,
                    "confirmation": None,
                    "log_tail": "",
                    "artifacts": [],
                    "result": {},
                    "exit_code": None,
                    "physical_stop_verified": False,
                    "control_lock_pending": False,
                    "error": None,
                }
                self.store.data["sessions"][sid] = s
                if key:
                    self.store.data["requests"][key] = {"input": frozen, "session_id": sid}
                self.save()  # Durable identity before any process can start.
                if self.config["backend"] == "mock":
                    from mock_backend import start

                    start(self, s)
                else:
                    threading.Thread(target=self.run_real, args=(s, timeout), daemon=True).start()
                result = self.snapshot(s)
            if key and key not in self.store.data["requests"]:
                self.store.data["requests"][key] = {"input": frozen, "result": result}
            self.save()
            return result

    def receipt(self, s, code):
        "Only interpret this invocation's outputs; never equate exit 0 with movement."
        op = s["operation_id"]
        directory = Path(s["directory"])
        log = (directory / "terminal.log").read_text(errors="replace")
        data = {
            "exit_code": code,
            "terminal_output": log[-16000:],
            "hardware_motion_verified": False,
        }
        parsed = []
        for line in log.splitlines():
            try:
                v = json.loads(line)
                if isinstance(v, dict):
                    parsed.append(v)
            except ValueError:
                pass
        # Some programs pretty-print JSON.
        if not parsed:
            try:
                v = json.loads(log.strip())
                if isinstance(v, dict):
                    parsed.append(v)
            except ValueError:
                pass
        if parsed:
            data["native_reports"] = parsed
        if op == "franka.pipeline.start":
            refs = [v.get("result") for v in parsed if isinstance(v.get("result"), str)]
            if not refs:
                raise ValueError("PIPELINE_RECEIPT_MISSING")
            p = self.store.owned(refs[-1])
            if not p.is_relative_to(directory.resolve()):
                raise ValueError("PIPELINE_RECEIPT_OUTSIDE_SESSION")
            r = json.loads(p.read_text())
            data["receipt"] = r
            allowed = {
                "plan": {"planned"},
                "prepare": {"offline_checks_passed"},
                "execute": {"executed_without_capture", "executed_and_captured"},
            }
            if (
                code != 0
                or r.get("status") != "succeeded"
                or r.get("outcome") not in allowed[s["parameters"]["mode"]]
            ):
                raise ValueError("PIPELINE_NOT_SUCCESSFUL: " + str(r.get("outcome")))
            data["capture_completed"] = r.get("outcome") == "executed_and_captured"
            if data["capture_completed"]:
                capture_path = self.store.owned(p.parent / "capture_result.json")
                capture = json.loads(capture_path.read_text())
                samples = capture.get("sample_count")
                if capture.get("completed") is not True or isinstance(samples, bool) or not isinstance(samples, int) or samples < 2:
                    raise ValueError("PIPELINE_CAPTURE_INCOMPLETE")
                files = capture.get("files")
                if not isinstance(files, list) or not files:
                    raise ValueError("PIPELINE_CAPTURE_FILES_MISSING")
                for name in files:
                    if not isinstance(name, str) or Path(name).is_absolute():
                        raise ValueError("PIPELINE_CAPTURE_FILE_INVALID")
                    captured = self.store.owned(p.parent / name)
                    if not captured.is_relative_to(p.parent) or not captured.is_file() or captured.stat().st_size == 0:
                        raise ValueError("PIPELINE_CAPTURE_FILE_INVALID")
                data["capture_receipt"] = capture
            data["hardware_motion_verified"] = s["parameters"]["mode"] == "execute"
        elif op in {"franka.home", "franka.offline.execute", "franka.offline.validate"}:
            # Native offline audit path is fixed by vendor; accept ONLY an exact
            # freshly created receipt path printed by this invocation, never latest-directory scans.
            if op.startswith("franka.offline."):
                candidates = re.findall(
                    r"(/[A-Za-z0-9_./-]+(?:result\.json|offline_[A-Za-z0-9_/-]+))", log
                )
                audit = (Path(self.config["workspace"]) / "execution_logs").resolve()
                for value in candidates:
                    p = Path(value)
                    if p.is_dir():
                        p = p / "result.json"
                    if (
                        not p.resolve().is_relative_to(audit)
                        or p.is_symlink()
                        or not p.is_file()
                        or p.stat().st_mtime < s["started_unix"] - 0.001
                    ):
                        continue
                    # Read only exact receipt, do not expose its external paths.
                    target = directory / "native_result.json"
                    target.write_bytes(p.read_bytes())
            receipts = [
                p
                for p in directory.rglob("*.json")
                if p.name in {"result.json", "native_result.json"}
            ]
            if not receipts:
                raise ValueError("NATIVE_RECEIPT_MISSING")
            r = json.loads(receipts[-1].read_text())
            data["receipt"] = r
            if not r.get("success"):
                raise ValueError("NATIVE_REPORTED_FAILURE")
            if op == "franka.offline.execute" and (
                r.get("dry_run") is not False
                or r.get("mock") is not False
                or r.get("ribbon_guard") is not True
            ):
                raise ValueError("OFFLINE_REAL_EXECUTION_NOT_VERIFIED")
            data["hardware_motion_verified"] = (
                bool(r.get("moved")) if op == "franka.home" else op == "franka.offline.execute"
            )
        elif op == "franka.delta.move":
            if "MOTION_DONE_NS" not in log:
                raise ValueError("MOTION_COMPLETION_MARKER_MISSING")
            data["hardware_motion_verified"] = True
        elif op == "franka.state.read":
            if not parsed:
                raise ValueError("STATE_JSON_MISSING")
            r = parsed[-1]
            for k, n in [("q", 7), ("dq", 7), ("O_T_EE", 16)]:
                v = r.get(k)
                if (
                    not isinstance(v, list)
                    or len(v) != n
                    or any(
                        isinstance(x, bool)
                        or not isinstance(x, (int, float))
                        or not __import__("math").isfinite(x)
                        for x in v
                    )
                ):
                    raise ValueError("INVALID_ROBOT_STATE")
            if "robot_mode" not in r:
                raise ValueError("ROBOT_MODE_MISSING")
            data["robot_state"] = r
        if code and not (op == "franka.ribbon.analyze" and code == 1):
            raise ValueError("PROCESS_EXIT_" + str(code))
        if op == "franka.ribbon.analyze":
            data["criteria_done"] = code == 0
        return data

    def run_real(self, s, timeout):
        fd = None
        proc = None
        try:
            with self.lock:
                if s["state"] == "cancelling":
                    s["state"] = "cancelled"
                    self.finish(s, 130, {"started": False})
                    return
                master, slave = pty.openpty()
                fd = master
            with self.lock:
                if s["state"] == "cancelling":
                    os.close(slave)
                    s["state"] = "cancelled"
                    self.finish(s, 130, {"started": False})
                    return
                launcher = [
                    __import__("sys").executable,
                    "-I",
                    str(PACKAGE / "vendor_launch.py"),
                    str(os.getpid()),
                    *shell_launch(self.config, s["argv"]),
                ]
                proc = subprocess.Popen(
                    launcher,
                    stdin=slave,
                    stdout=slave,
                    stderr=slave,
                    start_new_session=True,
                    close_fds=True,
                    env={
                        "PATH": "/usr/local/bin:/usr/bin:/bin",
                        "HOME": str(Path.home()),
                        "LANG": "C.UTF-8",
                    },
                )
                os.close(slave)
                s["process_id"] = proc.pid
                self.live[s["session_id"]] = (master, proc)
                self.save()
            deadline = time.monotonic() + timeout
            pending = ""
            last_signature = None
            epoch = 0
            logpath = Path(s["directory"]) / "terminal.log"
            with logpath.open("wb") as log:
                while True:
                    if time.monotonic() > deadline:
                        with self.lock:
                            s.update(
                                state="failed",
                                control_lock_pending=True,
                                error="SESSION_TIMEOUT",
                                confirmation=None,
                            )
                            self.save()
                        if proc.poll() is None:
                            os.killpg(proc.pid, signal.SIGINT)
                        # Keep the separate control lock until a fresh stop check passes.
                        break
                    ready, _, _ = select.select([master], [], [], 0.1)
                    if ready:
                        try:
                            b = os.read(master, 8192)
                        except OSError as ex:
                            if ex.errno == errno.EIO:
                                b = b""
                            else:
                                raise
                        if b:
                            log.write(b)
                            log.flush()
                            pending = (pending + b.decode("utf-8", errors="replace"))[-32000:]
                            with self.lock:
                                if s.get("prompt_epoch", 0) != epoch:
                                    epoch = s.get("prompt_epoch", 0)
                                    pending = b.decode("utf-8", errors="replace")
                                    last_signature = None
                                s["log_tail"] = pending[-16000:]
                                # Search the recent prompt, not historical tokens or echoed input.
                                actions = None
                                tail = pending[-4000:]
                                actions = prompt_actions(s["operation_id"], tail)
                                signature = (actions, tail) if actions else None
                                if (
                                    actions
                                    and signature != last_signature
                                    and s["state"] == "running"
                                ):
                                    last_signature = signature
                                    self.prompt(s, actions, tail)
                                self.save()
                        if not b and proc.poll() is not None:
                            break
                    if proc.poll() is not None and not ready:
                        break
                    with self.lock:
                        # After a response, remove the old prompt before a fresh MOVE.
                        if s["state"] == "running" and last_signature is not None:
                            pending = ""
                            last_signature = None
            code = proc.wait(timeout=5)
            with self.lock:
                if s["state"] in {"failed", "cancelling"}:
                    s.update(
                        state="failed",
                        control_lock_pending=True,
                        error=s.get("error") or "CANCELLED_STOP_CHECK_REQUIRED",
                        confirmation=None,
                        exit_code=code,
                        finished_at=now(),
                    )
                    self.store.collect(s)
                    self.save()
                else:
                    try:
                        data = self.receipt(s, code)
                        self.finish(s, code, data)
                    except (ValueError, KeyError, OSError) as ex:
                        self.finish(
                            s, code, {"exit_code": code, "hardware_motion_verified": False}, str(ex)
                        )
        except Exception as ex:
            with self.lock:
                # A failure after Popen may have occurred after partial movement.
                self.finish(s, proc.poll() if proc else None,
                            {"started": proc is not None}, "PROCESS_ERROR: " + str(ex))
        finally:
            if fd is not None:
                os.close(fd)
            with self.lock:
                # Do not forget a still-running controller after timeout/error.
                if proc is None or proc.poll() is not None:
                    self.live.pop(s["session_id"], None)
                elif s["state"] == "failed":
                    s["control_lock_pending"] = True
                    self.save()
                self.refresh_failed_lock(s)


def serve(config):
    root = Path(config["state_dir"])
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = (root / "broker.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    sock = root / "broker.sock"
    sock.unlink(missing_ok=True)
    broker = Broker(config)

    class Handler(socketserver.StreamRequestHandler):
        def handle(self):
            self.connection.settimeout(20)
            try:
                b = self.rfile.readline(1024 * 1024 + 1)
                if len(b) > 1024 * 1024:
                    raise ValueError("MESSAGE_TOO_LARGE")
                req = json.loads(b)
                if req["config_hash"] != broker.fingerprint:
                    raise ValueError("CONFIG_CHANGED_RESTART_BROKER_AFTER_SESSIONS_END")
                result = envelope(
                    config["backend"], broker.invoke(req["operation_id"], req["parameters"])
                )
            except Exception as ex:
                result = envelope(
                    config["backend"],
                    error={"code": "ADAPTER_REQUEST_FAILED", "message": str(ex)[:2000]},
                )
            self.wfile.write((canonical(result) + "\n").encode())

    with socketserver.ThreadingUnixStreamServer(str(sock), Handler) as server:
        os.chmod(sock, 0o600)
        (root / "broker.pid").write_text(str(os.getpid()))
        server.serve_forever()
