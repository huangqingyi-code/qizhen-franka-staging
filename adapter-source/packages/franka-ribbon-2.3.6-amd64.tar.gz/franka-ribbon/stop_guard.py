"""Read-only stop checks; never recover errors, command motion or trust an exit code alone."""

import json
import math
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

TERMINAL = {"succeeded", "failed", "cancelled", "unknown"}
MOTION = {"franka.delta.move", "franka.home", "franka.ribbon.run",
          "franka.pipeline.start", "franka.offline.execute"}
# Values from this deployment's libfranka/include/franka/robot_state.h.
STOPPED_MODES = {1, 4, 5}  # Idle, Reflex, UserStopped; no automatic recovery.
VELOCITY_TOLERANCE = 1e-2  # rad/s, every joint and every sample
POSITION_TOLERANCE = 1e-4  # rad, maximum sampled range per joint
SAMPLES = 2
SAMPLE_INTERVAL = 0.25


def session_blocks(s):
    if s["state"] not in TERMINAL:
        return True
    if s["state"] == "unknown":  # Backward compatibility for pre-upgrade state files.
        return not s.get("operator_verified_stopped")
    if "control_lock_pending" in s:
        return bool(s["control_lock_pending"])
    # Old failed motion sessions had no separate lock; do not silently trust them.
    return s["state"] == "failed" and s.get("operation_id") in MOTION


def read_snapshot(config):
    reader = Path(config["workspace"]) / "libfranka/build/examples/read_franka_state"
    result = subprocess.run(
        [str(reader), config["robot_ip"]], stdin=subprocess.DEVNULL,
        capture_output=True, text=True, timeout=2, check=True,
    )
    return json.loads(result.stdout)


def verify_stopped(config, s):
    """Use robot samples only; execution-process lifetime does not gate unlocking."""
    report = {"verified": False, "checked_at": datetime.now(timezone.utc).isoformat(),
              "samples": [], "velocity_tolerance_rad_s": VELOCITY_TOLERANCE,
              "position_tolerance_rad": POSITION_TOLERANCE}
    try:
        for index in range(SAMPLES):
            if index:
                time.sleep(SAMPLE_INTERVAL)
            state = read_snapshot(config)
            if not isinstance(state, dict):
                raise ValueError("INVALID_ROBOT_STATE")
            mode = state.get("robot_mode")
            if isinstance(mode, bool) or not isinstance(mode, int) or mode not in STOPPED_MODES:
                raise ValueError("ROBOT_MODE_NOT_STOPPED")
            for name in ("q", "dq"):
                values = state.get(name)
                if not isinstance(values, list) or len(values) != 7 or any(
                    isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
                    for v in values
                ):
                    raise ValueError("INVALID_ROBOT_STATE_" + name.upper())
            report["samples"].append({"robot_mode": mode, "q": state["q"], "dq": state["dq"]})
            if any(abs(v) > VELOCITY_TOLERANCE for v in state["dq"]):
                raise ValueError("ROBOT_STILL_MOVING")
        for joint in range(7):
            positions = [v["q"][joint] for v in report["samples"]]
            if max(positions) - min(positions) > POSITION_TOLERANCE:
                raise ValueError("ROBOT_POSITION_NOT_STABLE")
        report["verified"] = True
    except (OSError, ValueError, IndexError, TypeError, subprocess.SubprocessError) as ex:
        report["error"] = str(ex)[:1000]
    return report
