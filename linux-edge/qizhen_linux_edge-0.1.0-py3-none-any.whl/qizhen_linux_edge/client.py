"""Outbound-only Qizhen Platform client and Connector loop."""

from __future__ import annotations

import hashlib
import json
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from typing import Any

import rfc8785

from qizhen_linux_edge import __version__
from qizhen_linux_edge.adapters import AdapterManager
from qizhen_linux_edge.journal import CommandJournal
from qizhen_linux_edge.state import EdgePaths


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def content_hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(rfc8785.dumps(value)).hexdigest()


class PlatformError(RuntimeError):
    def __init__(self, status: int, body: dict[str, Any]):
        self.status = status
        self.body = body
        super().__init__(f"Platform request failed with HTTP {status}: {body.get('error', body)}")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file_pointer, code, message, headers, new_url):
        return None


class PlatformClient:
    def __init__(self, base_url: str, *, timeout: int = 65):
        if not isinstance(base_url, str):
            raise ValueError("Platform URL is required")
        parsed = urllib.parse.urlsplit(base_url)
        local_http = parsed.scheme == "http" and parsed.hostname in {
            "127.0.0.1",
            "localhost",
            "::1",
        }
        if parsed.scheme != "https" and not local_http:
            raise ValueError("Platform URL must use HTTPS outside localhost")
        if (
            not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
        ):
            raise ValueError(
                "Platform URL must be an origin without credentials, query, or fragment"
            )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.opener = urllib.request.build_opener(_NoRedirect)

    def request(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        *,
        token: str | None = None,
        idempotency_key: str | None = None,
    ) -> tuple[int, dict[str, Any]]:
        headers = {"Accept": "application/json", "User-Agent": f"qizhen-linux-edge/{__version__}"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        data = None
        if body is not None:
            data = json.dumps(body, ensure_ascii=False, allow_nan=False).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path, data=data, headers=headers, method=method
        )
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                payload = response.read(2 * 1024 * 1024)
                return response.status, json.loads(payload) if payload else {}
        except urllib.error.HTTPError as error:
            payload = error.read(2 * 1024 * 1024)
            try:
                body_value = json.loads(payload) if payload else {}
            except json.JSONDecodeError:
                body_value = {"error": "non-JSON Platform error"}
            raise PlatformError(error.code, body_value) from error


class ConnectorService:
    def __init__(self, paths: EdgePaths, client: PlatformClient | None = None):
        self.paths = paths
        self.paths.ensure()
        self.config = paths.read_config()
        base_url = self.config.get("platform_url")
        self.client = client or PlatformClient(base_url)
        self.adapters = AdapterManager(paths)
        self.journal = CommandJournal(paths.journal)

    @classmethod
    def start_pairing(
        cls, paths: EdgePaths, platform_url: str, device_name: str
    ) -> dict[str, Any]:
        paths.ensure()
        config = paths.read_config()
        instance_key = config.get("connector_instance_key") or secrets.token_urlsafe(48)
        client = PlatformClient(platform_url)
        _status, pairing = client.request(
            "POST",
            "/api/v1/device-pairings",
            {
                "schema_version": "1.0",
                "device_name": device_name,
                "platform": "linux",
                "connector_version": __version__,
                "connector_instance_key": instance_key,
            },
        )
        paths.write_config(
            {
                "schema_version": "1.0",
                "platform_url": platform_url.rstrip("/"),
                "device_name": device_name,
                "connector_instance_key": instance_key,
                "pairing_token": pairing["pairing_token"],
                "verification_code": pairing["verification_code"],
                "verification_url": pairing["verification_url"],
                "status": "pairing",
            }
        )
        return {
            "status": "pairing",
            "verification_code": pairing["verification_code"],
            "verification_url": pairing["verification_url"],
            "expires_at": pairing["expires_at"],
        }

    def poll_pairing(self) -> dict[str, Any]:
        token = self.config.get("pairing_token")
        instance_key = self.config.get("connector_instance_key")
        if not token or not instance_key:
            raise ValueError("no pending pairing")
        try:
            status, value = self.client.request(
                "POST",
                "/api/v1/device-pairings:poll",
                {"schema_version": "1.0", "connector_instance_key": instance_key},
                token=token,
            )
        except PlatformError as error:
            raise error
        if status == 202:
            return {"status": value["status"], "verification_code": value["verification_code"]}
        self.config.update(
            {
                "status": "paired",
                "device_id": value["device_id"],
                "connector_deployment_id": value["connector_deployment_id"],
                "connector_state_version": value["connector_state_version"],
                "access_token": value["access_token"],
                "credential_expires_at": value["expires_at"],
            }
        )
        self.config.pop("pairing_token", None)
        self.config.pop("verification_code", None)
        self.config.pop("verification_url", None)
        self.paths.write_config(self.config)
        return self.public_status()

    def public_status(self) -> dict[str, Any]:
        config = self.paths.read_config()
        return {
            key: config.get(key)
            for key in (
                "status",
                "device_name",
                "verification_code",
                "verification_url",
                "device_id",
                "connector_deployment_id",
                "credential_expires_at",
                "last_connected_at",
                "last_error",
            )
            if config.get(key) is not None
        }

    def _credential(self) -> tuple[str, str, int]:
        config = self.paths.read_config()
        token = config.get("access_token")
        connector_id = config.get("connector_deployment_id")
        state_version = config.get("connector_state_version")
        if not token or not connector_id or not isinstance(state_version, int):
            raise ValueError("Connector is not paired")
        return token, connector_id, state_version

    def rotate_credential(self) -> dict[str, Any]:
        token, connector_id, _state_version = self._credential()
        _status, value = self.client.request(
            "POST",
            "/api/v1/device-credentials:rotate",
            {
                "schema_version": "1.0",
                "connector_deployment_id": connector_id,
                "connector_version": __version__,
            },
            token=token,
        )
        self.config = self.paths.read_config()
        self.config.update(
            {
                "access_token": value["access_token"],
                "credential_expires_at": value["expires_at"],
                "connector_state_version": value["connector_state_version"],
            }
        )
        self.paths.write_config(self.config)
        return self.public_status()

    def sync_capabilities(self) -> dict[str, Any]:
        token, connector_id, _state_version = self._credential()
        config = self.paths.read_config()
        revision = int(config.get("catalog_revision", 0)) + 1
        body = {
            "schema_version": "1.0",
            "connector_deployment_id": connector_id,
            "catalog_revision": revision,
            "generated_at": _now(),
            "adapters": self.adapters.capability_adapters(),
        }
        body["snapshot_hash"] = content_hash(body)
        _status, acknowledgement = self.client.request(
            "POST",
            f"/api/v1/resource-federation/site-connectors/{connector_id}/capability-snapshots:sync",
            body,
            token=token,
        )
        config.update({"catalog_revision": revision, "catalog_hash": body["snapshot_hash"]})
        self.paths.write_config(config)
        return acknowledgement

    def heartbeat(self) -> dict[str, Any]:
        token, connector_id, state_version = self._credential()
        config = self.paths.read_config()
        body: dict[str, Any] = {
            "schema_version": "1.0",
            "observed_state_version": state_version,
            "observed_at": _now(),
            "status": "ready",
            "capacity": {"accepting_work": True, "active_jobs": 0, "queued_jobs": 0},
            "maintenance": {"active": False},
        }
        if config.get("catalog_revision") and config.get("catalog_hash"):
            body.update(
                {
                    "observed_catalog_revision": config["catalog_revision"],
                    "observed_catalog_hash": config["catalog_hash"],
                }
            )
        _status, value = self.client.request(
            "POST",
            f"/api/v1/resource-federation/site-connectors/{connector_id}/heartbeat",
            body,
            token=token,
        )
        config.update(
            {
                "last_connected_at": body["observed_at"],
                "connector_state_version": value.get("state_version", state_version),
                "status": "paired",
            }
        )
        config.pop("last_error", None)
        self.paths.write_config(config)
        return value

    def _report(self, command_id: str, job_id: str, body: dict[str, Any]) -> None:
        token, _connector_id, _state_version = self._credential()
        key = "linux-edge-" + hashlib.sha256(
            json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        self.journal.enqueue_report(command_id, job_id, key, body)
        self.client.request(
            "POST",
            f"/api/v1/resource-federation/resource-jobs/{job_id}:reconcile",
            body,
            token=token,
            idempotency_key=key,
        )
        self.journal.clear_report(command_id, key)

    def recover_reports(self) -> None:
        token, _connector_id, _state_version = self._credential()
        for command_id, job_id, key, body in self.journal.reports():
            self.client.request(
                "POST",
                f"/api/v1/resource-federation/resource-jobs/{job_id}:reconcile",
                body,
                token=token,
                idempotency_key=key,
            )
            self.journal.clear_report(command_id, key)

    def _current_job(self, job_id: str) -> dict[str, Any]:
        token, _connector_id, _state_version = self._credential()
        _status, job = self.client.request(
            "GET", f"/api/v1/resource-federation/resource-jobs/{job_id}", token=token
        )
        return job

    def process_command(self, command: dict[str, Any]) -> dict[str, Any]:
        command_fields = {
            "command_id",
            "command_type",
            "resource_job_id",
            "expected_state_version",
            "issued_at",
            "document",
        }
        if set(command) != command_fields:
            raise ValueError("unexpected command fields")
        prior = self.journal.receive(command)
        if prior is not None:
            self._report(command["command_id"], command["resource_job_id"], prior)
            return prior
        current = self._current_job(command["resource_job_id"])
        now = _now()
        try:
            if current["state_version"] != command["expected_state_version"]:
                raise ValueError("command expected_state_version does not match the resource job")
            if command["command_type"] == "execute":
                document = command["document"]
                allowed = {
                    "schema_version",
                    "run_resource_binding_id",
                    "adapter_revision_id",
                    "adapter_version",
                    "adapter_hash",
                    "artifact_hash",
                    "operation",
                    "parameters",
                    "input_resource_refs",
                    "idempotency_key",
                }
                if set(document) != allowed or document["schema_version"] != "1.0":
                    raise ValueError("invalid frozen execute command")
                if not isinstance(document["parameters"], dict):
                    raise ValueError("Adapter parameters must be a JSON object")
                if document["input_resource_refs"]:
                    raise ValueError(
                        "Linux edge runtime does not support input resource references"
                    )
                result = self.adapters.invoke(
                    document["adapter_revision_id"],
                    document["adapter_version"],
                    document["artifact_hash"],
                    document["adapter_hash"],
                    document["operation"],
                    document["parameters"],
                )
                current.update(
                    {
                        "execution_status": "succeeded",
                        "delivery_status": "delivered",
                        "outcome_confidence": "confirmed",
                        "remote_job_ref": f"linux-edge:{command['command_id']}",
                        "inline_result": result,
                        "error": None,
                        "state_version": current["state_version"] + 1,
                        "updated_at": now,
                        "finished_at": now,
                    }
                )
            elif command["command_type"] == "cancel":
                current.update(
                    {
                        "cancel_status": (
                            "superseded"
                            if current["execution_status"] in {"succeeded", "failed"}
                            else "unsupported"
                        ),
                        "state_version": current["state_version"] + 1,
                        "updated_at": now,
                    }
                )
            else:
                raise ValueError("unsupported command type")
        except Exception as error:
            current.update(
                {
                    "execution_status": "failed",
                    "delivery_status": "failed",
                    "outcome_confidence": "reported",
                    "inline_result": None,
                    "error": {"code": "linux_edge_execution_failed", "message": str(error)[:1000]},
                    "state_version": current["state_version"] + 1,
                    "updated_at": now,
                    "finished_at": now,
                }
            )
        self.journal.complete(command["command_id"], current)
        self._report(command["command_id"], command["resource_job_id"], current)
        return current

    def run_once(self, max_wait_seconds: int = 0) -> int:
        self.recover_reports()
        self.heartbeat()
        token, connector_id, _state_version = self._credential()
        _status, batch = self.client.request(
            "POST",
            f"/api/v1/resource-federation/site-connectors/{connector_id}/commands:pull",
            {
                "schema_version": "1.0",
                "cursor": None,
                "max_wait_seconds": max_wait_seconds,
                "max_commands": 10,
            },
            token=token,
        )
        for command in batch["commands"]:
            self.process_command(command)
        return len(batch["commands"])

    def run_forever(self) -> None:
        delay = 1
        while True:
            try:
                self.run_once(max_wait_seconds=30)
                delay = 1
            except (TimeoutError, OSError, PlatformError) as error:
                config = self.paths.read_config()
                config.update({"status": "disconnected", "last_error": str(error)[:1000]})
                self.paths.write_config(config)
                time.sleep(delay)
                delay = min(delay * 2, 60)
