"""Durable command receipts and report outbox."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


def _encode(value: Any) -> str:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )


class CommandJournal:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(path, timeout=30)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS receipts(
                command_id TEXT PRIMARY KEY,
                command TEXT NOT NULL,
                result TEXT
            );
            CREATE TABLE IF NOT EXISTS report_outbox(
                command_id TEXT PRIMARY KEY,
                resource_job_id TEXT NOT NULL,
                request_key TEXT NOT NULL,
                body TEXT NOT NULL
            );
            """
        )

    def receive(self, command: dict[str, Any]) -> dict[str, Any] | None:
        command_id = command.get("command_id")
        if not isinstance(command_id, str) or not command_id:
            raise ValueError("command_id is required")
        encoded = _encode(command)
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO receipts(command_id,command,result) VALUES(?,?,NULL)",
                (command_id, encoded),
            )
            row = self.db.execute(
                "SELECT command,result FROM receipts WHERE command_id=?", (command_id,)
            ).fetchone()
            if row[0] != encoded:
                raise ValueError("command identity was reused with different content")
        return json.loads(row[1]) if row[1] else None

    def complete(self, command_id: str, result: dict[str, Any]) -> None:
        with self.db:
            updated = self.db.execute(
                "UPDATE receipts SET result=? WHERE command_id=?",
                (_encode(result), command_id),
            )
            if updated.rowcount != 1:
                raise ValueError("unknown command receipt")

    def enqueue_report(
        self, command_id: str, resource_job_id: str, request_key: str, body: dict[str, Any]
    ) -> None:
        encoded = _encode(body)
        with self.db:
            self.db.execute(
                "INSERT INTO report_outbox(command_id,resource_job_id,request_key,body) "
                "VALUES(?,?,?,?) "
                "ON CONFLICT(command_id) DO UPDATE SET resource_job_id=excluded.resource_job_id,"
                "request_key=excluded.request_key,body=excluded.body",
                (command_id, resource_job_id, request_key, encoded),
            )

    def reports(self) -> list[tuple[str, str, str, dict[str, Any]]]:
        return [
            (row[0], row[1], row[2], json.loads(row[3]))
            for row in self.db.execute(
                "SELECT command_id,resource_job_id,request_key,body "
                "FROM report_outbox ORDER BY rowid"
            )
        ]

    def clear_report(self, command_id: str, request_key: str) -> None:
        with self.db:
            self.db.execute(
                "DELETE FROM report_outbox WHERE command_id=? AND request_key=?",
                (command_id, request_key),
            )

    def close(self) -> None:
        self.db.close()
