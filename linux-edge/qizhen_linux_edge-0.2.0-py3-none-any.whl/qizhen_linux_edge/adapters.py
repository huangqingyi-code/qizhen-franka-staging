"""Pinned Adapter installation and structured invocation."""

from __future__ import annotations

import hashlib
import json
import os
import re
import selectors
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import rfc8785
from jsonschema import Draft202012Validator

from qizhen_linux_edge.discovery import architecture
from qizhen_linux_edge.state import EdgePaths

ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")
VERSION_PATTERN = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$")
MAX_PACKAGE_BYTES = 64 * 1024 * 1024
MAX_MESSAGE_BYTES = 1024 * 1024


class AdapterInvocationError(RuntimeError):
    """A schema-valid Adapter response explicitly reported an operation failure."""

    def __init__(self, result: dict[str, Any]):
        self.result = result
        error = result.get("error")
        details = error if isinstance(error, dict) else {}
        self.code = str(details.get("code") or "adapter_request_failed")[:96]
        self.retryable = details.get("retryable") is True
        super().__init__(str(details.get("message") or "Adapter reported ok=false"))


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _sha256_directory(path: Path) -> str:
    digest = hashlib.sha256()
    total = 0
    entries = sorted(path.rglob("*"))
    for item in entries:
        if item.is_symlink():
            raise ValueError("Adapter package may not contain symbolic links")
        if not item.is_file() and not item.is_dir():
            raise ValueError("Adapter package may contain only regular files and directories")
    files = [item for item in entries if item.is_file()]
    if not files:
        raise ValueError("Adapter package is empty")
    for item in files:
        relative = item.relative_to(path).as_posix()
        total += item.stat().st_size
        if total > MAX_PACKAGE_BYTES:
            raise ValueError("Adapter package exceeds 64 MiB")
        digest.update(relative.encode())
        digest.update(b"\0")
        with item.open("rb") as stream:
            while block := stream.read(1024 * 1024):
                digest.update(block)
        digest.update(b"\0")
    return "sha256:" + digest.hexdigest()


def package_hash(path: Path) -> str:
    return _sha256_directory(path) if path.is_dir() else _sha256_file(path)


def _package_size(path: Path) -> int:
    if path.is_file():
        return path.stat().st_size
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


def _content_hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(rfc8785.dumps(value)).hexdigest()


def _extract_tar(archive: Path, destination: Path) -> Path:
    with tarfile.open(archive, "r:gz") as package:
        members = package.getmembers()
        total = sum(member.size for member in members if member.isfile())
        if total > MAX_PACKAGE_BYTES:
            raise ValueError("Adapter package exceeds 64 MiB")
        for member in members:
            target = (destination / member.name).resolve()
            if destination.resolve() not in target.parents and target != destination.resolve():
                raise ValueError("Adapter package contains a path traversal")
            if not member.isfile() and not member.isdir():
                raise ValueError("Adapter package contains an unsupported entry type")
        package.extractall(destination, filter="data")
    roots = [item for item in destination.iterdir() if item.name != "__MACOSX"]
    if len(roots) == 1 and roots[0].is_dir():
        return roots[0]
    return destination


def _validate_manifest(value: dict[str, Any]) -> dict[str, Any]:
    required = {
        "schema_version",
        "adapter_revision_id",
        "version",
        "entrypoint",
        "runtime_requirements",
        "operations",
    }
    if set(value) - {"artifact_delivery"} != required:
        raise ValueError(f"Adapter manifest fields must be exactly {sorted(required)}")
    if value["schema_version"] != "1.0":
        raise ValueError("unsupported Adapter manifest version")
    adapter_id = value["adapter_revision_id"]
    if not isinstance(adapter_id, str) or not ID_PATTERN.fullmatch(adapter_id):
        raise ValueError("invalid adapter_revision_id")
    if not isinstance(value["version"], str) or not VERSION_PATTERN.fullmatch(value["version"]):
        raise ValueError("invalid Adapter version")
    entrypoint = value["entrypoint"]
    if not isinstance(entrypoint, str) or Path(entrypoint).name != entrypoint:
        raise ValueError("Adapter entrypoint must be a package-local filename")
    requirements = value["runtime_requirements"]
    if requirements != {
        "operating_system": "linux",
        "architecture": architecture(),
        "interactive_session_required": False,
        "arbitrary_shell_allowed": False,
    }:
        raise ValueError("Adapter runtime requirements do not match this Linux host")
    operations = value["operations"]
    if not isinstance(operations, list) or not 1 <= len(operations) <= 100:
        raise ValueError("Adapter must declare between 1 and 100 operations")
    seen: set[str] = set()
    operation_fields = {
        "operation_id",
        "name",
        "summary",
        "input_schema",
        "output_schema",
        "side_effect",
        "idempotency",
        "timeout_seconds",
        "supports_cancel",
    }
    for operation in operations:
        if not isinstance(operation, dict) or set(operation) != operation_fields:
            raise ValueError("invalid Adapter operation fields")
        operation_id = operation["operation_id"]
        if not isinstance(operation_id, str) or not ID_PATTERN.fullmatch(operation_id):
            raise ValueError("invalid operation_id")
        if operation_id in seen:
            raise ValueError("duplicate operation_id")
        seen.add(operation_id)
        if operation["side_effect"] not in {"none", "reversible", "high_impact"}:
            raise ValueError("invalid operation side_effect")
        if operation["idempotency"] not in {"safe", "keyed", "unsupported"}:
            raise ValueError("invalid operation idempotency")
        if not isinstance(operation["name"], str) or not operation["name"].strip():
            raise ValueError("invalid operation name")
        if not isinstance(operation["summary"], str) or not operation["summary"].strip():
            raise ValueError("invalid operation summary")
        if not isinstance(operation["supports_cancel"], bool):
            raise ValueError("invalid operation supports_cancel")
        if not isinstance(operation["timeout_seconds"], int) or not (
            1 <= operation["timeout_seconds"] <= 300
        ):
            raise ValueError("invalid operation timeout")
        Draft202012Validator.check_schema(operation["input_schema"])
        Draft202012Validator.check_schema(operation["output_schema"])
    if "artifact_delivery" in value:
        delivery = value["artifact_delivery"]
        if (
            not isinstance(delivery, dict)
            or set(delivery)
            != {"protocol", "status_operation", "list_operation", "start_operations"}
            or delivery["protocol"] != "1.0"
        ):
            raise ValueError("invalid artifact delivery protocol")
        starts = delivery["start_operations"]
        if (
            not isinstance(starts, list)
            or not starts
            or len(starts) > 100
            or any(not isinstance(op, str) or op not in seen for op in starts)
            or len(starts) != len(set(starts))
        ):
            raise ValueError("artifact start operations must be published and unique")
        for field in ("status_operation", "list_operation"):
            operation = next(
                (op for op in operations if op["operation_id"] == delivery[field]), None
            )
            if (
                operation is None
                or operation["side_effect"] != "none"
                or operation["idempotency"] != "safe"
            ):
                raise ValueError("artifact delivery operations must be published safe reads")
    return value


class AdapterManager:
    def __init__(self, paths: EdgePaths):
        self.paths = paths
        self.paths.ensure()

    def _materialize(self, source: Path, destination: Path) -> Path:
        if source.is_dir():
            shutil.copytree(source, destination, symlinks=True)
            _sha256_directory(destination)
            return destination
        if not source.is_file() or not source.name.endswith(".tar.gz"):
            raise ValueError("Adapter package must be a directory or .tar.gz archive")
        destination.mkdir(mode=0o700)
        return _extract_tar(source, destination)

    @staticmethod
    def _manifest(package: Path) -> dict[str, Any]:
        path = package / "adapter.json"
        if not path.is_file():
            raise ValueError("Adapter package is missing adapter.json")
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("Adapter manifest must be a JSON object")
        value = _validate_manifest(value)
        entrypoint = package / value["entrypoint"]
        if not entrypoint.is_file() or entrypoint.is_symlink():
            raise ValueError("Adapter entrypoint is missing or unsafe")
        return value

    @staticmethod
    def _run_self_test(package: Path, manifest: dict[str, Any]) -> None:
        completed = subprocess.run(
            [sys.executable, "-I", str(package / manifest["entrypoint"]), "--self-test"],
            input="{}\n",
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
            cwd=package,
            env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},
        )
        if completed.returncode != 0:
            message = (completed.stderr or completed.stdout).strip()[:1000]
            raise ValueError(f"Adapter self-test failed: {message}")
        try:
            result = json.loads(completed.stdout)
        except json.JSONDecodeError as error:
            raise ValueError("Adapter self-test did not return JSON") from error
        if not isinstance(result, dict) or result.get("ok") is not True:
            raise ValueError("Adapter self-test did not report ok=true")

    def install(self, source: Path, expected_hash: str) -> dict[str, Any]:
        source = source.resolve()
        actual_hash = package_hash(source)
        package_size = _package_size(source)
        if actual_hash != expected_hash:
            raise ValueError(
                f"Adapter package hash mismatch: expected {expected_hash}, got {actual_hash}"
            )
        staging_parent = self.paths.adapters / ".staging"
        staging_parent.mkdir(mode=0o700, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=staging_parent) as temporary:
            staged = Path(temporary) / "package"
            package = self._materialize(source, staged)
            manifest = self._manifest(package)
            self._run_self_test(package, manifest)
            adapter_id = manifest["adapter_revision_id"]
            version = manifest["version"]
            existing_state = self.paths.read_adapter_state(adapter_id)
            immutable_conflict = next(
                (
                    item
                    for item in existing_state.get("versions", [])
                    if item["version"] == version and item["artifact_hash"] != actual_hash
                ),
                None,
            )
            if immutable_conflict:
                raise ValueError("Adapter id and version already map to a different package hash")
            destination = self.paths.adapters / adapter_id / "versions" / version / actual_hash[7:]
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                shutil.copytree(package, destination)
            state = existing_state
            previous = state.get("current")
            record = {
                "version": version,
                "artifact_hash": actual_hash,
                "size_bytes": package_size,
                "path": str(destination),
                "installed_at": _now(),
                "manifest": manifest,
                "lifecycle_state": "current",
                "running": False,
            }
            versions = [
                {**item, "lifecycle_state": "retained", "running": False}
                for item in state.get("versions", [])
                if item["artifact_hash"] != actual_hash
            ]
            versions.append(record)
            state = {"current": actual_hash, "previous": previous, "versions": versions}
            self.paths.write_adapter_state(adapter_id, state)
            return record

    def _record(
        self, adapter_id: str, *, version: str | None = None, artifact_hash: str | None = None
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self._validate_adapter_id(adapter_id)
        state = self.paths.read_adapter_state(adapter_id)
        selected = [
            item
            for item in state.get("versions", [])
            if (version is None or item["version"] == version)
            and (artifact_hash is None or item["artifact_hash"] == artifact_hash)
        ]
        if len(selected) != 1:
            raise ValueError("exactly one installed Adapter version must match")
        return state, selected[0]

    @staticmethod
    def _validate_adapter_id(adapter_id: str) -> None:
        if not isinstance(adapter_id, str) or not ID_PATTERN.fullmatch(adapter_id):
            raise ValueError("invalid adapter_revision_id")

    def set_running(self, adapter_id: str, running: bool) -> dict[str, Any]:
        self._validate_adapter_id(adapter_id)
        state = self.paths.read_adapter_state(adapter_id)
        current = state.get("current")
        if not current:
            raise ValueError("Adapter is not installed")
        for item in state["versions"]:
            if item["artifact_hash"] == current:
                if running:
                    self._run_self_test(Path(item["path"]), item["manifest"])
                item["running"] = running
                item["lifecycle_state"] = "current" if running else "disabled"
                self.paths.write_adapter_state(adapter_id, state)
                return item
        raise ValueError("current Adapter package is missing")

    def rollback(self, adapter_id: str) -> dict[str, Any]:
        self._validate_adapter_id(adapter_id)
        state = self.paths.read_adapter_state(adapter_id)
        target = state.get("previous")
        current = state.get("current")
        if not target or target == current:
            raise ValueError("no retained Adapter version is available for rollback")
        for item in state["versions"]:
            if item["artifact_hash"] == target:
                self._run_self_test(Path(item["path"]), item["manifest"])
                item["lifecycle_state"] = "current"
                item["running"] = True
            elif item["artifact_hash"] == current:
                item["lifecycle_state"] = "retained"
                item["running"] = False
        state["current"], state["previous"] = target, current
        self.paths.write_adapter_state(adapter_id, state)
        return next(item for item in state["versions"] if item["artifact_hash"] == target)

    def health(self, adapter_id: str) -> dict[str, Any]:
        self._validate_adapter_id(adapter_id)
        state = self.paths.read_adapter_state(adapter_id)
        current = state.get("current")
        if not current:
            return {"status": "not_installed", "adapter_revision_id": adapter_id}
        item = next(record for record in state["versions"] if record["artifact_hash"] == current)
        try:
            self._run_self_test(Path(item["path"]), item["manifest"])
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            return {"status": "unhealthy", "adapter_revision_id": adapter_id, "error": str(error)}
        return {
            "status": "ready" if item.get("running") else "stopped",
            "adapter_revision_id": adapter_id,
            "version": item["version"],
            "artifact_hash": item["artifact_hash"],
        }

    def invoke(
        self,
        adapter_id: str,
        version: str,
        artifact_hash: str,
        adapter_hash: str,
        operation_id: str,
        parameters: dict[str, Any],
    ) -> dict[str, Any]:
        encoded = json.dumps(parameters, ensure_ascii=False, allow_nan=False).encode()
        if len(encoded) > MAX_MESSAGE_BYTES:
            raise ValueError("Adapter input exceeds one MiB")
        _state, item = self._record(adapter_id, version=version, artifact_hash=artifact_hash)
        if self.adapter_hash(item) != adapter_hash:
            raise ValueError("frozen Adapter hash does not match the installed revision")
        if not item.get("running"):
            raise ValueError("Adapter is not running")
        operation = next(
            (
                value
                for value in item["manifest"]["operations"]
                if value["operation_id"] == operation_id
            ),
            None,
        )
        if operation is None:
            raise ValueError("Adapter operation is not published by this installed version")
        Draft202012Validator(operation["input_schema"]).validate(parameters)
        package = Path(item["path"])
        completed = subprocess.run(
            [
                sys.executable,
                "-I",
                str(package / item["manifest"]["entrypoint"]),
                "--invoke",
                operation_id,
            ],
            input=json.dumps(parameters, ensure_ascii=False) + "\n",
            capture_output=True,
            text=True,
            timeout=operation["timeout_seconds"],
            check=False,
            cwd=package,
            env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},
        )
        if completed.returncode != 0:
            raise RuntimeError((completed.stderr or "Adapter invocation failed").strip()[:2000])
        if len(completed.stdout.encode()) > MAX_MESSAGE_BYTES:
            raise ValueError("Adapter output exceeds one MiB")
        result = json.loads(completed.stdout)
        if not isinstance(result, dict):
            raise ValueError("Adapter output must be a JSON object")
        Draft202012Validator(operation["output_schema"]).validate(result)
        if result.get("ok") is False:
            self._log(adapter_id, operation_id, "failed")
            raise AdapterInvocationError(result)
        self._log(adapter_id, operation_id, "succeeded")
        return result

    def export_part(self, document, artifact_id, offset, count, target):
        """Private binary stdout channel; no caller-controlled path or shell."""
        if not ID_PATTERN.fullmatch(artifact_id) or offset < 0 or not 1 <= count <= 8 * 1024 * 1024:
            raise ValueError("invalid artifact part")
        _state, item = self._record(
            document["adapter_revision_id"],
            version=document["adapter_version"],
            artifact_hash=document["artifact_hash"],
        )
        if not item.get("running") or self.adapter_hash(item) != document["adapter_hash"]:
            raise ValueError("artifact Adapter revision is not active or hash mismatched")
        if item["manifest"].get("artifact_delivery", {}).get("protocol") != "1.0":
            raise ValueError("Adapter does not declare binary artifact export")
        package = Path(item["path"])
        with (
            tempfile.TemporaryFile() as errors,
            subprocess.Popen(
                [
                    sys.executable,
                    "-I",
                    str(package / item["manifest"]["entrypoint"]),
                    "--export-artifact",
                    artifact_id,
                    "--offset",
                    str(offset),
                    "--count",
                    str(count),
                ],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=errors,
                cwd=package,
                env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},
            ) as process,
        ):
            received = 0
            deadline = time.monotonic() + 60
            try:
                with selectors.DefaultSelector() as selector:
                    selector.register(process.stdout, selectors.EVENT_READ)
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0 or not selector.select(remaining):
                            raise TimeoutError("artifact export timed out")
                        block = os.read(
                            process.stdout.fileno(), min(1024 * 1024, count - received + 1)
                        )
                        if not block:
                            break
                        received += len(block)
                        if received > count:
                            raise ValueError("artifact export exceeds requested part")
                        target.write(block)
                if process.wait(timeout=max(0.1, deadline - time.monotonic())) != 0:
                    raise ValueError("artifact export failed or source changed")
            except BaseException:
                process.kill()
                process.wait()
                raise
        return received

    def _log(self, adapter_id: str, operation_id: str, status: str) -> None:
        self._validate_adapter_id(adapter_id)
        path = self.paths.logs / f"{adapter_id}.jsonl"
        with open(  # noqa: PTH123 - mode-preserving opener is required for private logs
            path, "a", encoding="utf-8", opener=lambda p, f: os.open(p, f, 0o600)
        ) as stream:
            stream.write(
                json.dumps(
                    {
                        "at": _now(),
                        "adapter_revision_id": adapter_id,
                        "operation": operation_id,
                        "status": status,
                    },
                    sort_keys=True,
                )
                + "\n"
            )

    def log_summary(self, adapter_id: str, limit: int = 20) -> list[dict[str, Any]]:
        self._validate_adapter_id(adapter_id)
        path = self.paths.logs / f"{adapter_id}.jsonl"
        if not path.exists():
            return []
        lines = path.read_text(encoding="utf-8").splitlines()[-max(1, min(limit, 100)) :]
        return [json.loads(line) for line in lines]

    def capability_adapters(self) -> list[dict[str, Any]]:
        adapters: list[dict[str, Any]] = []
        for state_path in sorted(self.paths.adapters.glob("*/state.json")):
            state = json.loads(state_path.read_text(encoding="utf-8"))
            current = state.get("current")
            for item in state.get("versions", []):
                if item["artifact_hash"] != current or not item.get("running"):
                    continue
                adapters.append(self._capability_adapter(item))
        return adapters

    @staticmethod
    def _capability_adapter(item: dict[str, Any]) -> dict[str, Any]:
        manifest = item["manifest"]
        return {
            "adapter_revision_id": manifest["adapter_revision_id"],
            "adapter_version": manifest["version"],
            "artifact": {
                "source": "local_install",
                "package_id": "package_" + item["artifact_hash"][7:39],
                "content_hash": item["artifact_hash"],
                "size_bytes": item["size_bytes"],
                "installed_at": item["installed_at"],
            },
            "runtime_requirements": manifest["runtime_requirements"],
            "lifecycle_state": "current",
            "verification": {
                "status": "passed",
                "tested_at": item["installed_at"],
                "checks_total": 1,
                "checks_passed": 1,
            },
            "operations": [
                {
                    **{
                        key: operation[key]
                        for key in (
                            "operation_id",
                            "name",
                            "summary",
                            "input_schema",
                            "output_schema",
                            "side_effect",
                            "idempotency",
                            "timeout_seconds",
                            "supports_cancel",
                        )
                    },
                    "availability": {"status": "available", "reason": None},
                }
                for operation in manifest["operations"]
            ],
        }

    @classmethod
    def adapter_hash(cls, item: dict[str, Any]) -> str:
        adapter = cls._capability_adapter(item)
        manifest = item["manifest"]
        document = {
            "schema_version": "1.0",
            "adapter_revision_id": manifest["adapter_revision_id"],
            "version": manifest["version"],
            "adapter_kind": "local_api",
            "artifact": adapter["artifact"],
            "entrypoint": f"connector:{manifest['adapter_revision_id']}",
            "operations": [
                {
                    "operation_id": operation["operation_id"],
                    "side_effect": operation["side_effect"],
                    "idempotency": {
                        "safe": "native",
                        "keyed": "adapter_keyed",
                        "unsupported": "unsupported",
                    }[operation["idempotency"]],
                    "supports_query": True,
                    "supports_cancel": operation["supports_cancel"],
                    "supports_resume": False,
                }
                for operation in manifest["operations"]
            ],
            "runtime_requirements": manifest["runtime_requirements"],
            "status": "local_verified",
        }
        return _content_hash(document)
