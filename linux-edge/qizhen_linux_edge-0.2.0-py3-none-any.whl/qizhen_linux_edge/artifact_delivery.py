"""Durable background artifact export; never replays a motion/start command."""

from __future__ import annotations

import hashlib
import tempfile
import threading
import time
from urllib.parse import quote

from qizhen_linux_edge.adapters import AdapterManager
from qizhen_linux_edge.journal import CommandJournal


def identity(*parts):
    return hashlib.sha256(":".join(parts).encode()).hexdigest()


class ArtifactDeliveryWorker:
    def __init__(self, paths, client):
        self.paths = paths
        self.client = client
        self.adapters = AdapterManager(paths)
        self.journal = CommandJournal(paths.journal)
        self.stop = threading.Event()

    def request(self, method, path, body=None):
        token = self.paths.read_config().get("access_token")
        return self.client.request(
            method,
            path,
            body,
            token=token,
            **({"timeout": 900} if path.endswith(":complete") else {}),
        )[1]

    def invoke(self, document, operation, parameters):
        response = self.adapters.invoke(
            document["adapter_revision_id"],
            document["adapter_version"],
            document["artifact_hash"],
            document["adapter_hash"],
            operation,
            parameters,
        )
        return response["data"]

    def discover(self):
        # Recover enrollment even after a crash between command completion and reporting.
        for rowid, command, result in self.journal.completed_receipts():
            if command["command_type"] != "execute":
                self.journal.advance_artifact_discovery(rowid)
                continue
            document = command["document"]
            response = result.get("inline_result") or {}
            data = response.get("data")
            session = data.get("session_id") if isinstance(data, dict) else None
            if not isinstance(session, str) or response.get("ok") is not True:
                self.journal.advance_artifact_discovery(rowid)
                continue
            try:
                _state, item = self.adapters._record(
                    document["adapter_revision_id"],
                    version=document["adapter_version"],
                    artifact_hash=document["artifact_hash"],
                )
            except ValueError:
                self.journal.advance_artifact_discovery(rowid)
                continue
            protocol = item["manifest"].get("artifact_delivery")
            if protocol and document["operation"] in protocol["start_operations"]:
                key = identity(
                    command["resource_job_id"],
                    document["adapter_revision_id"],
                    document["artifact_hash"],
                    session,
                )
                self.journal.add_artifact_session(
                    key,
                    {
                        "session_id": session,
                        "document": {
                            k: document[k]
                            for k in (
                                "adapter_revision_id",
                                "adapter_version",
                                "artifact_hash",
                                "adapter_hash",
                            )
                        },
                        "job_id": command["resource_job_id"],
                        "protocol": protocol,
                    },
                )
            self.journal.advance_artifact_discovery(rowid)

    @staticmethod
    def base(session):
        return "/api/v1/resource-federation/resource-jobs/" + quote(session["job_id"], safe="")

    def report_session(self, session, state):
        summary = {
            "generating": "设备产物正在生成。",
            "uploading": "设备产物正在上传。",
            "ready": "设备产物已上传，可预览或下载。",
            "failed": "设备产物上传失败，正在等待重试。",
        }[state]
        self.request(
            "POST",
            self.base(session)
            + "/artifact-sessions/"
            + quote(session["session_id"], safe="")
            + ":report",
            {"state": state, "summary": summary},
        )

    def poll(self, key, session, now):
        protocol, document = session["protocol"], session["document"]
        offset = 0
        while True:
            page = self.invoke(
                document,
                protocol["list_operation"],
                {"session_id": session["session_id"], "offset": offset, "limit": 100},
            )
            for artifact in page["artifacts"]:
                if (
                    page.get("artifact_index", {}).get("state") != "ready"
                    or artifact.get("state", "ready") != "ready"
                ):
                    continue
                metadata = {
                    k: artifact[k]
                    for k in ("artifact_id", "name", "mime_type", "size_bytes", "sha256")
                }
                metadata["session_id"] = session["session_id"]
                self.journal.add_artifact_file(
                    identity(key, artifact["artifact_id"]),
                    key,
                    {"session": session, "metadata": metadata},
                )
            next_offset = page.get("next_offset")
            if next_offset is None:
                break
            if next_offset <= offset:
                raise ValueError("artifact pagination did not advance")
            offset = next_offset
        index_state = page.get("artifact_index", {}).get("state", "generating")
        pending = self.journal.pending_artifact_count(key)
        state = (
            "failed"
            if index_state == "failed" or self.journal.failed_artifact_count(key)
            else "ready"
            if index_state == "ready" and not pending
            else "uploading"
            if pending
            else "generating"
        )
        self.report_session(session, state)
        self.journal.poll_artifact_session(key, now, done=state == "ready")

    def transfer(self, key, item, attempts, now):
        session, metadata = item["session"], item["metadata"]
        path = self.base(session) + "/artifacts"
        try:
            if "transfer_id" not in item:
                status = self.request("POST", path, metadata)
                item["transfer_id"] = status["transfer_id"]
                # Durable before sending the first byte.
                self.journal.save_artifact_file(key, item, now)
            path += "/" + quote(item["transfer_id"], safe="")
            status = self.request("GET", path)
            if status["state"] == "ready":
                self.journal.save_artifact_file(key, item, now, done=True)
                return
            missing = sorted(set(range(status["part_count"])) - set(status["uploaded_parts"]))
            if missing:
                index = missing[0]
                count = min(
                    status["part_bytes"],
                    max(0, metadata["size_bytes"] - index * status["part_bytes"]),
                )
                with tempfile.TemporaryFile() as part:
                    actual = self.adapters.export_part(
                        session["document"],
                        metadata["artifact_id"],
                        index * status["part_bytes"],
                        max(1, count),
                        part,
                    )
                    if actual != count:
                        raise ValueError("artifact export length changed")
                    part.seek(0)
                    self.client.put_file(
                        path + f"/parts/{index}",
                        part,
                        count,
                        token=self.paths.read_config().get("access_token"),
                    )
                self.journal.save_artifact_file(key, item, now + 0.1)
            else:
                self.request("POST", path + ":complete")
                self.journal.save_artifact_file(key, item, now, done=True)
        except Exception as error:
            item["last_error"] = str(error)[:1000]
            self.journal.save_artifact_file(
                key, item, now + min(300, 2 ** min(attempts + 1, 8)), attempts=attempts + 1
            )
            try:
                if "transfer_id" in item:
                    self.request(
                        "POST",
                        path + ":report-failure",
                        {"message": "File transfer failed; Connector will retry."},
                    )
                self.report_session(session, "failed")
            except Exception:
                pass

    def tick(self, now=None):
        now = time.time() if now is None else now
        self.discover()
        for key, session in self.journal.artifact_sessions(now):
            try:
                self.poll(key, session, now)
            except Exception:
                self.journal.poll_artifact_session(key, now)
                try:
                    self.report_session(session, "failed")
                except Exception:
                    pass
        item = self.journal.next_artifact_file(now)
        if item:
            self.transfer(*item, now)

    def run(self):
        try:
            while not self.stop.is_set():
                try:
                    self.tick()
                except Exception:
                    pass
                self.stop.wait(1)
        finally:
            self.journal.close()
