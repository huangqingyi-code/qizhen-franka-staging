"""Durable command receipts and report outbox."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


def _encode(value: Any) -> str:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )


class CommandJournal:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(path, timeout=30)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS receipts(
                command_id TEXT PRIMARY KEY,
                command TEXT NOT NULL,
                result TEXT
            );
            CREATE TABLE IF NOT EXISTS report_outbox(
                command_id TEXT PRIMARY KEY,
                resource_job_id TEXT NOT NULL,
                request_key TEXT NOT NULL,
                body TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS artifact_sessions(
                session_key TEXT PRIMARY KEY,
                body TEXT NOT NULL,
                done INTEGER NOT NULL DEFAULT 0,
                next_poll REAL NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS artifact_files(
                file_key TEXT PRIMARY KEY,
                session_key TEXT NOT NULL,
                body TEXT NOT NULL,
                done INTEGER NOT NULL DEFAULT 0,
                attempts INTEGER NOT NULL DEFAULT 0,
                next_attempt REAL NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS artifact_discovery(
                command_id TEXT PRIMARY KEY
            );
            """
        )

    def receive(self, command: dict[str, Any]) -> dict[str, Any] | None:
        command_id = command.get("command_id")
        if not isinstance(command_id, str) or not command_id:
            raise ValueError("command_id is required")
        encoded = _encode(command)
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO receipts(command_id,command,result) VALUES(?,?,NULL)",
                (command_id, encoded),
            )
            row = self.db.execute(
                "SELECT command,result FROM receipts WHERE command_id=?", (command_id,)
            ).fetchone()
            if row[0] != encoded:
                raise ValueError("command identity was reused with different content")
        return json.loads(row[1]) if row[1] else None

    def complete(self, command_id: str, result: dict[str, Any]) -> None:
        with self.db:
            updated = self.db.execute(
                "UPDATE receipts SET result=? WHERE command_id=?",
                (_encode(result), command_id),
            )
            if updated.rowcount != 1:
                raise ValueError("unknown command receipt")

    def enqueue_report(
        self, command_id: str, resource_job_id: str, request_key: str, body: dict[str, Any]
    ) -> None:
        encoded = _encode(body)
        with self.db:
            self.db.execute(
                "INSERT INTO report_outbox(command_id,resource_job_id,request_key,body) "
                "VALUES(?,?,?,?) "
                "ON CONFLICT(command_id) DO UPDATE SET resource_job_id=excluded.resource_job_id,"
                "request_key=excluded.request_key,body=excluded.body",
                (command_id, resource_job_id, request_key, encoded),
            )

    def reports(self) -> list[tuple[str, str, str, dict[str, Any]]]:
        return [
            (row[0], row[1], row[2], json.loads(row[3]))
            for row in self.db.execute(
                "SELECT command_id,resource_job_id,request_key,body "
                "FROM report_outbox ORDER BY rowid"
            )
        ]

    def clear_report(self, command_id: str, request_key: str) -> None:
        with self.db:
            self.db.execute(
                "DELETE FROM report_outbox WHERE command_id=? AND request_key=?",
                (command_id, request_key),
            )

    def close(self) -> None:
        self.db.close()

    def completed_receipts(self):
        return [
            (command_id, json.loads(c), json.loads(r))
            for command_id, c, r in self.db.execute(
                "SELECT command_id,command,result FROM receipts "
                "WHERE result IS NOT NULL AND NOT EXISTS "
                "(SELECT 1 FROM artifact_discovery d WHERE d.command_id=receipts.command_id) "
                "ORDER BY rowid LIMIT 50"
            )
        ]

    def advance_artifact_discovery(self, command_id):
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO artifact_discovery(command_id) VALUES(?)", (command_id,)
            )

    def add_artifact_session(self, key, body):
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO artifact_sessions(session_key,body) VALUES (?,?)",
                (key, _encode(body)),
            )

    def artifact_sessions(self, now):
        return [
            (k, json.loads(b))
            for k, b in self.db.execute(
                "SELECT session_key,body FROM artifact_sessions WHERE done=0 AND next_poll<=?",
                (now,),
            )
        ]

    def poll_artifact_session(self, key, now, done=False):
        with self.db:
            self.db.execute(
                "UPDATE artifact_sessions SET next_poll=?,done=? WHERE session_key=?",
                (now + 5, int(done), key),
            )

    def add_artifact_file(self, key, session_key, body):
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO artifact_files(file_key,session_key,body) VALUES (?,?,?)",
                (key, session_key, _encode(body)),
            )

    def pending_artifact_count(self, session_key):
        return self.db.execute(
            "SELECT count(*) FROM artifact_files WHERE session_key=? AND done=0", (session_key,)
        ).fetchone()[0]

    def failed_artifact_count(self, session_key):
        return self.db.execute(
            "SELECT count(*) FROM artifact_files WHERE session_key=? AND done=0 AND attempts>0",
            (session_key,),
        ).fetchone()[0]

    def next_artifact_file(self, now):
        row = self.db.execute(
            "SELECT file_key,body,attempts FROM artifact_files WHERE done=0 "
            "AND next_attempt<=? ORDER BY next_attempt,rowid LIMIT 1",
            (now,),
        ).fetchone()
        return (row[0], json.loads(row[1]), row[2]) if row else None

    def save_artifact_file(self, key, body, now, *, done=False, attempts=0):
        with self.db:
            self.db.execute(
                "UPDATE artifact_files SET body=?,done=?,attempts=?,next_attempt=? "
                "WHERE file_key=?",
                (_encode(body), int(done), attempts, now, key),
            )
