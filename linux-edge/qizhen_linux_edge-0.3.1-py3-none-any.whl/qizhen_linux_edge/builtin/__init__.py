"""Bundled read-only Linux Adapter assets."""
