#!/usr/bin/env python3
"""Standalone read-only Linux inventory Adapter entrypoint."""

from __future__ import annotations

import json
import os
import platform
import shutil
import socket
import subprocess
import sys
from pathlib import Path
from typing import Any


def _architecture() -> str:
    machine = platform.machine().lower()
    return {"x86_64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(machine, machine)


def _os_release() -> dict[str, str]:
    values: dict[str, str] = {}
    path = Path("/etc/os-release")
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            key, separator, value = line.partition("=")
            if separator and key.isupper():
                values[key] = value.strip().strip('"')[:256]
    return values


def _software() -> list[dict[str, str]]:
    status = Path("/var/lib/dpkg/status")
    packages: list[dict[str, str]] = []
    if status.exists():
        current: dict[str, str] = {}
        for line in status.read_text(encoding="utf-8", errors="replace").splitlines() + [""]:
            if not line:
                if current.get("Package") and current.get("Status") == "install ok installed":
                    packages.append(
                        {
                            "name": current["Package"][:256],
                            "version": current.get("Version", "")[:256],
                        }
                    )
                current = {}
                if len(packages) >= 2000:
                    break
            elif ": " in line and not line.startswith((" ", "\t")):
                key, value = line.split(": ", 1)
                if key in {"Package", "Version", "Status"}:
                    current[key] = value
    return sorted(packages, key=lambda item: item["name"])


def _sdks() -> list[dict[str, str]]:
    probes = {
        "python3": ["python3", "--version"],
        "node": ["node", "--version"],
        "java": ["java", "-version"],
        "gcc": ["gcc", "--version"],
        "docker": ["docker", "--version"],
    }
    result: list[dict[str, str]] = []
    for name, command in probes.items():
        executable = shutil.which(command[0])
        if not executable:
            continue
        completed = subprocess.run(
            [executable, *command[1:]],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
            env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},
        )
        output = (completed.stdout or completed.stderr).splitlines()
        result.append({"name": name, "version": (output[0] if output else "unknown")[:256]})
    return result


def _ports() -> list[dict[str, Any]]:
    result: set[tuple[str, int]] = set()
    for filename, family in (("/proc/net/tcp", "ipv4"), ("/proc/net/tcp6", "ipv6")):
        path = Path(filename)
        if not path.exists():
            continue
        for line in path.read_text(encoding="ascii", errors="replace").splitlines()[1:]:
            fields = line.split()
            if len(fields) >= 4 and fields[3] == "0A":
                try:
                    result.add((family, int(fields[1].rsplit(":", 1)[1], 16)))
                except (IndexError, ValueError):
                    continue
    return [{"family": family, "port": port} for family, port in sorted(result)[:2000]]


def inventory() -> dict[str, Any]:
    release = _os_release()
    interfaces = []
    for index, name in socket.if_nameindex():
        state_path = Path("/sys/class/net") / name / "operstate"
        state = state_path.read_text(encoding="utf-8").strip() if state_path.exists() else "unknown"
        interfaces.append({"index": index, "name": name[:64], "state": state[:32]})
    return {
        "host": {
            "hostname": socket.gethostname()[:255],
            "operating_system": "linux",
            "distribution": release.get("ID", "unknown"),
            "distribution_version": release.get("VERSION_ID", "unknown"),
            "kernel": platform.release()[:256],
            "architecture": _architecture(),
            "cpu_count": os.cpu_count(),
        },
        "software": _software(),
        "sdks": _sdks(),
        "ports": _ports(),
        "interfaces": interfaces,
    }


def main() -> int:
    if sys.argv[1:] == ["--self-test"]:
        print(json.dumps({"ok": True, "architecture": _architecture()}))
        return 0
    if sys.argv[1:] != ["--invoke", "linux.inventory.read"]:
        print("unsupported invocation", file=sys.stderr)
        return 2
    parameters = json.load(sys.stdin)
    if parameters:
        print("linux.inventory.read accepts no parameters", file=sys.stderr)
        return 2
    print(json.dumps(inventory(), ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
