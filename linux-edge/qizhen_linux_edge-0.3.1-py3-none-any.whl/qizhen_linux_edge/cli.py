"""Command line interface for Qizhen Linux Edge."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any

from qizhen_linux_edge import __version__
from qizhen_linux_edge.adapters import AdapterManager, package_hash
from qizhen_linux_edge.client import ConnectorService, PlatformClient, PlatformError
from qizhen_linux_edge.discovery import architecture, snapshot
from qizhen_linux_edge.state import EdgePaths


def _emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def _builtin_manifest() -> dict[str, Any]:
    object_schema = {"type": "object"}
    return {
        "schema_version": "1.0",
        "adapter_revision_id": "adapter_linux_system_inventory",
        "version": "1.0.0",
        "entrypoint": "handler.py",
        "runtime_requirements": {
            "operating_system": "linux",
            "architecture": architecture(),
            "interactive_session_required": False,
            "arbitrary_shell_allowed": False,
        },
        "operations": [
            {
                "operation_id": "linux.inventory.read",
                "name": "读取 Linux 主机清单",
                "summary": "只读发现主机、已安装软件、SDK、监听端口和网络接口。",
                "input_schema": {"type": "object", "additionalProperties": False},
                "output_schema": object_schema,
                "side_effect": "none",
                "idempotency": "safe",
                "timeout_seconds": 30,
                "supports_cancel": False,
            }
        ],
    }


def _install_builtin(manager: AdapterManager) -> dict[str, Any]:
    source = Path(__file__).with_name("builtin") / "system_inventory.py"
    with tempfile.TemporaryDirectory() as temporary:
        package = Path(temporary) / "system-inventory"
        package.mkdir()
        shutil.copyfile(source, package / "handler.py")
        (package / "adapter.json").write_text(
            json.dumps(_builtin_manifest(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return manager.install(package, package_hash(package))


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qizhen-linux-edge")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)

    pair = sub.add_parser("pair")
    pair.add_argument("--url", required=True)
    pair.add_argument("--name", required=True)
    pair_status = sub.add_parser("pair-status")
    pair_status.add_argument("--poll", action="store_true")
    sub.add_parser("status")
    sub.add_parser("doctor")
    sub.add_parser("discover")
    sub.add_parser("rotate-credential")
    run = sub.add_parser("run")
    run.add_argument("--once", action="store_true")

    capabilities = sub.add_parser("capabilities")
    capabilities_sub = capabilities.add_subparsers(dest="capabilities_command", required=True)
    capabilities_sub.add_parser("list")
    capabilities_sub.add_parser("sync")

    adapter = sub.add_parser("adapter")
    adapter_sub = adapter.add_subparsers(dest="adapter_command", required=True)
    adapter_sub.add_parser("install-builtin")
    for name in ("install", "update"):
        install = adapter_sub.add_parser(name)
        install.add_argument("package", type=Path)
        install.add_argument("--sha256", required=True)
    for name in ("start", "stop", "health", "rollback", "logs"):
        action = adapter_sub.add_parser(name)
        action.add_argument("adapter_id")
        if name == "logs":
            action.add_argument("--limit", type=int, default=20)
    return parser


def run(arguments: list[str] | None = None) -> int:
    args = _parser().parse_args(arguments)
    paths = EdgePaths.from_environment()
    manager = AdapterManager(paths)
    if args.command == "pair":
        _emit(ConnectorService.start_pairing(paths, args.url, args.name))
    elif args.command == "pair-status":
        if args.poll:
            config = paths.read_config()
            service = ConnectorService(paths, PlatformClient(config["platform_url"]))
            _emit(service.poll_pairing())
        else:
            client = PlatformClient(paths.read_config()["platform_url"])
            _emit(ConnectorService(paths, client).public_status())
    elif args.command == "status":
        config = paths.read_config()
        if not config:
            _emit({"status": "not_configured"})
        else:
            _emit(ConnectorService(paths, PlatformClient(config["platform_url"])).public_status())
    elif args.command == "doctor":
        _emit(
            {
                "ok": sys.platform.startswith("linux") and architecture() in {"amd64", "arm64"},
                "platform": sys.platform,
                "architecture": architecture(),
                "state_root": str(paths.root),
                "state_mode": oct(paths.root.stat().st_mode & 0o777),
            }
        )
    elif args.command == "discover":
        _emit(snapshot())
    elif args.command == "rotate-credential":
        _emit(ConnectorService(paths).rotate_credential())
    elif args.command == "run":
        service = ConnectorService(paths)
        if args.once:
            _emit({"commands_processed": service.run_once()})
        else:
            service.run_forever()
    elif args.command == "capabilities":
        if args.capabilities_command == "list":
            _emit({"adapters": manager.capability_adapters()})
        else:
            _emit(ConnectorService(paths).sync_capabilities())
    elif args.command == "adapter":
        if args.adapter_command == "install-builtin":
            _emit(_install_builtin(manager))
        elif args.adapter_command in {"install", "update"}:
            expected = args.sha256 if args.sha256.startswith("sha256:") else "sha256:" + args.sha256
            _emit(manager.install(args.package, expected))
        elif args.adapter_command == "start":
            _emit(manager.set_running(args.adapter_id, True))
        elif args.adapter_command == "stop":
            _emit(manager.set_running(args.adapter_id, False))
        elif args.adapter_command == "health":
            _emit(manager.health(args.adapter_id))
        elif args.adapter_command == "rollback":
            _emit(manager.rollback(args.adapter_id))
        elif args.adapter_command == "logs":
            _emit({"items": manager.log_summary(args.adapter_id, args.limit)})
    return 0


def main() -> None:
    try:
        raise SystemExit(run())
    except (KeyError, OSError, PlatformError, ValueError, RuntimeError) as error:
        _emit({"error": {"code": "linux_edge_error", "message": str(error)}})
        raise SystemExit(1) from error


if __name__ == "__main__":
    main()
