"""Track only command-created sessions; forward durable local events without tool calls."""

import hashlib
import json
import logging
import subprocess
import sys
import threading
from urllib.parse import quote

from qizhen_linux_edge.adapters import AdapterManager
from qizhen_linux_edge.journal import CommandJournal

logger = logging.getLogger(__name__)


def read_events(adapters, document, session_id, after):
    _, item = adapters._record(
        document["adapter_revision_id"],
        version=document["adapter_version"],
        artifact_hash=document["artifact_hash"],
    )
    if adapters.adapter_hash(item) != document["adapter_hash"]:
        raise ValueError("Frozen session Adapter hash mismatch")
    from pathlib import Path

    result = subprocess.run(
        [
            sys.executable,
            "-I",
            str(Path(item["path"]) / item["manifest"]["entrypoint"]),
            "--session-events",
        ],
        input=json.dumps({"session_id": session_id, "after": after, "max_wait_seconds": 15}),
        capture_output=True,
        text=True,
        timeout=20,
        check=True,
        env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},
    )
    if len(result.stdout.encode()) > 1024 * 1024:
        raise ValueError("Session event page exceeds budget")
    page = json.loads(result.stdout)
    if (
        not isinstance(page, dict)
        or set(page) != {"events"}
        or not isinstance(page["events"], list)
    ):
        raise ValueError("Invalid session event page")
    prior = after
    for event in page["events"]:
        if (
            set(event) != {"revision", "output"}
            or type(event["revision"]) is not int
            or event["revision"] <= prior
            or not isinstance(event["output"], dict)
            or (event["output"].get("data") or {}).get("session_id") != session_id
        ):
            raise ValueError("Invalid session event")
        prior = event["revision"]
    return page["events"]


class SessionDeliveryWorker:
    def __init__(self, paths, client):
        self.paths, self.client = paths, client
        self.stop = threading.Event()
        self.threads = {}

    def discover(self, journal):
        for command_id, command, receipt in journal.session_receipts():
            if command.get("command_type") != "execute":
                journal.finish_session_discovery(command_id)
                continue
            response = receipt.get("inline_result")
            data = response.get("data") if isinstance(response, dict) else None
            if (
                not isinstance(data, dict)
                or not isinstance(data.get("session_id"), str)
                or not data["session_id"]
            ):
                journal.finish_session_discovery(command_id)
                continue
            document = command.get("document", {})
            try:
                _, item = AdapterManager(self.paths)._record(
                    document["adapter_revision_id"],
                    version=document["adapter_version"],
                    artifact_hash=document["artifact_hash"],
                )
            except ValueError:
                journal.finish_session_discovery(command_id)
                continue  # Never substitute the current version for a missing frozen package.
            operation = next(
                (
                    o
                    for o in item["manifest"]["operations"]
                    if o["operation_id"] == document["operation"]
                ),
                {},
            )
            if operation.get("async_session") and data.get("session_id"):
                journal.track_session(
                    command_id,
                    {
                        "job_id": command["resource_job_id"],
                        "session_id": data["session_id"],
                        "document": document,
                    },
                )
            journal.finish_session_discovery(command_id)

    def deliver(self, command_id, session):
        journal = CommandJournal(self.paths.journal)
        adapters = AdapterManager(self.paths)
        try:
            while not self.stop.is_set():
                try:
                    after = journal.session_cursor(command_id)
                    pending = journal.pending_session_events(command_id)
                    if not pending:
                        pending = read_events(
                            adapters, session["document"], session["session_id"], after
                        )
                        journal.queue_session_events(command_id, pending)
                    for event in pending:
                        if self.stop.is_set():
                            return
                        token = self.paths.read_config().get("access_token")
                        path = (
                            "/api/v1/resource-federation/resource-jobs/"
                            + quote(session["job_id"], safe="")
                            + "/sessions/"
                            + quote(session["session_id"], safe="")
                            + "/events"
                        )
                        self.client.request(
                            "POST",
                            path,
                            event,
                            token=token,
                            idempotency_key="session-"
                            + hashlib.sha256(
                                f"{command_id}:{event['revision']}".encode()
                            ).hexdigest(),
                        )
                        data = event["output"].get("data") or {}
                        done = data.get("state") in {
                            "succeeded",
                            "failed",
                            "cancelled",
                        } and not data.get("control_lock_pending")
                        journal.ack_session_event(command_id, event["revision"], done)
                        if done:
                            return
                    return  # Yield the bounded reader slot fairly between sessions.
                except Exception:
                    logger.exception("session_delivery_retry command_id=%s", command_id)
                    self.stop.wait(2)
                    return
        finally:
            journal.defer_session(command_id)
            journal.close()

    def run(self):
        journal = CommandJournal(self.paths.journal)
        try:
            while not self.stop.is_set():
                try:
                    self.discover(journal)
                    self.threads = {k: t for k, t in self.threads.items() if t.is_alive()}
                    for command_id, session in journal.active_sessions():
                        if command_id not in self.threads and len(self.threads) < 8:
                            thread = threading.Thread(
                                target=self.deliver, args=(command_id, session), daemon=True
                            )
                            self.threads[command_id] = thread
                            thread.start()
                except Exception:
                    logger.exception("session_discovery_retry")
                self.stop.wait(1)
        finally:
            journal.close()
            for thread in self.threads.values():
                thread.join(timeout=21)
