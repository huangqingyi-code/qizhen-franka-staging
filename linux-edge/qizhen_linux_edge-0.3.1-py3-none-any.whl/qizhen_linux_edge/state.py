"""Private, crash-safe local state for the Linux Edge Runtime."""

from __future__ import annotations

import json
import os
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(f".{path.name}.{secrets.token_hex(6)}.tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def _read_json(path: Path, default: dict[str, Any] | None = None) -> dict[str, Any]:
    if not path.exists():
        return dict(default or {})
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"state at {path} is not a JSON object")
    return value


@dataclass(frozen=True)
class EdgePaths:
    root: Path

    @classmethod
    def from_environment(cls) -> EdgePaths:
        root = Path(
            os.environ.get("QIZHEN_EDGE_HOME", Path.home() / ".local" / "share" / "qizhen-edge")
        ).expanduser()
        return cls(root)

    @property
    def config(self) -> Path:
        return self.root / "connector.json"

    @property
    def adapters(self) -> Path:
        return self.root / "adapters"

    @property
    def development(self) -> Path:
        return self.root / "development"

    @property
    def logs(self) -> Path:
        return self.root / "logs"

    @property
    def journal(self) -> Path:
        return self.root / "commands.sqlite3"

    def ensure(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.root, 0o700)
        self.adapters.mkdir(mode=0o700, exist_ok=True)
        self.development.mkdir(mode=0o700, exist_ok=True)
        self.logs.mkdir(mode=0o700, exist_ok=True)

    def read_config(self) -> dict[str, Any]:
        return _read_json(self.config)

    def write_config(self, value: dict[str, Any]) -> None:
        self.ensure()
        _write_json(self.config, value)

    def adapter_state_path(self, adapter_id: str) -> Path:
        return self.adapters / adapter_id / "state.json"

    def read_adapter_state(self, adapter_id: str) -> dict[str, Any]:
        return _read_json(self.adapter_state_path(adapter_id), {"versions": [], "current": None})

    def write_adapter_state(self, adapter_id: str, value: dict[str, Any]) -> None:
        _write_json(self.adapter_state_path(adapter_id), value)
